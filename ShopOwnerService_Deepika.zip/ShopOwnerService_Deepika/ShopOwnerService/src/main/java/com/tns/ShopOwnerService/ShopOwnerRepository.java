package com.tns.ShopOwnerService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopOwnerRepository extends JpaRepository<ShopOwner, Integer>{
	
}



	

